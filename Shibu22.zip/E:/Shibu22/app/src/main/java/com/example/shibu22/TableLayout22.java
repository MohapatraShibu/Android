package com.example.shibu22;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TableLayout22 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_layout22);
    }
}
