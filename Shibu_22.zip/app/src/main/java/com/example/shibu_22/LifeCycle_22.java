package com.example.shibu_22;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
public class LifeCycle_22 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_life_cycle_22);
        Log.d("lifeCycle","onCreate");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("lifeCycle","onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.d("lifeCycle","onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("lifeCycle","onDestroy");
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("lifeCycle","onStart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d("lifeCycle","onResume");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("lifeCycle","onRestart");
    }
}
