package com.example.shibu_22;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
public class Login_22 extends AppCompatActivity {
    Button submitbutton;
    EditText txtName;
    EditText txtEmail;
    EditText txtPassword;
    EditText txtPhone;
    RadioGroup radiogrp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_22);
        submitbutton = (Button)findViewById(R.id.submitbutton);
        txtName = (EditText)findViewById(R.id.nameinput);
        txtEmail = (EditText)findViewById(R.id.emailinput);
        txtPassword = (EditText)findViewById(R.id.passwordinput);
        txtPhone = (EditText)findViewById(R.id.phoneinput);
        radiogrp = (RadioGroup) findViewById(R.id.genderinput);
        submitbutton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

            }
        });
    }
}
