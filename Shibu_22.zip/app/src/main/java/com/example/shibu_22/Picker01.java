package com.example.shibu_22;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Picker01 extends AppCompatActivity {
    DatePicker dtPicker;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picker01);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        dtPicker = (DatePicker) findViewById(R.id.dtPicker);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = dtPicker.getDayOfMonth() + " - " + (dtPicker.getMonth() + 1) + " - " + dtPicker.getYear();
                final AlertDialog alertDialog = new AlertDialog.Builder(Picker01.this).create();
                alertDialog.setMessage("Date:" + date);
                alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alertDialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        });
    }
}
