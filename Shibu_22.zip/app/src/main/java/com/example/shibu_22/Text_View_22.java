package com.example.shibu_22;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Text_View_22 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_view_22);
    }
}
